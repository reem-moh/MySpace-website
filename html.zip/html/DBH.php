<?php
  //localhost
  $dbServername="localhost";
  $dbUsername="root";
  $dbPassword="";
  //name of database
  $dbName="myspace";
  //for connection
  $conn= mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
